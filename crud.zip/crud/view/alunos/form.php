<?php
require_once(__DIR__ . "/../../controller/CursoController.php");
$cursoCont = new CursoController();
$cursos = $cursoCont->listar();

include_once(__DIR__ . "/../include/header.php");
?>

<h3>Inserir aluno</h3>

<form method="POST" action="">

    <div>
        <label for="txtNome">Nome: </label>
        <input type="text" name="nome" id="txtNome" placeholder="informe o nome...">
    </div>

    <div>
        <label for="numIdade">Idade: </label>
        <input type="number" name="idade" id="numIdade" placeholder="informe a idade...">
    </div>

    <div>
        <label for="selEstrang">Estrangeiro? </label>
        <select id="selEstrang" name="estrang">
            <option value="">selecione...</option>
            <option value="S">Sim</option>
            <option value="N">Não</option>  
        </select>
    </div>

    <div>
        <label for="selCurso">Curso: </label>
        <select id="selCurso" name="curso">
            <option value="">selecione...</option>
            <?php foreach($cursos as $curso): ?>
                <option value="<?= $curso->getId() ?>"><?= $curso ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div>
        <button type="submit">Gravar</button>
    </div>

</form>

<div style="color: red">
    <?= $msgErro ?>
</div>

<div>
    <a href="listar.php">Voltar</a>
</div>

<?php
include_once(__DIR__ . "/../include/footer.php");
?>