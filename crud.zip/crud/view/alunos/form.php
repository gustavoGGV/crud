<?php
require_once(__DIR__ . "/../../controller/CursoController.php");
$cursoCont = new CursoController();
$cursos = $cursoCont->listar();

include_once(__DIR__ . "/../include/header.php");
?>

<h3><?= $aluno && $aluno->getId() > 0 ? "Alterar" : "Inserir"?> aluno</h3>

<form method="POST" action="">

    <div>
        <label for="txtNome">Nome: </label>
        <input type="text" name="nome" id="txtNome" placeholder="informe o nome..." value="<?= $aluno ? $aluno->getNome() : '' ?>">
    </div>

    <div>
        <label for="numIdade">Idade: </label>
        <input type="number" name="idade" id="numIdade" placeholder="informe a idade..." value="<?= $aluno ? $aluno->getIdade() : null ?>">
    </div>

    <div>
        <label for="selEstrang">Estrangeiro? </label>
        <select id="selEstrang" name="estrang">
            <option value="">selecione...</option>
            <option value="S" <?= $aluno && $aluno->getEstrangeiro() === 'S' ? 'selected' : '' ?>>Sim</option>
            <option value="N" <?= $aluno && $aluno->getEstrangeiro() === 'N' ? 'selected' : '' ?>>Não</option>  
        </select>
    </div>

    <div>
        <label for="selCurso">Curso: </label>
        <select id="selCurso" name="curso">
            <option value="">selecione...</option>
            <?php foreach($cursos as $curso): ?>
                <option value="<?= $curso->getId() ?>" <?= $aluno && $aluno->getCurso() && $aluno->getCurso()->getId() === $curso->getId() ? 'selected' : '' ?>><?= $curso ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <input type="hidden" name="id" value="<?= $aluno ? $aluno->getId() : 0 ?>">

    <div>
        <button type="submit">Gravar</button>
    </div>

</form>

<div style="color: red">
    <?= $msgErro ?>
</div>

<div>
    <a href="listar.php">Voltar</a>
</div>

<?php
include_once(__DIR__ . "/../include/footer.php");
?>