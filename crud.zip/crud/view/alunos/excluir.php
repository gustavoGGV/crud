<?php

require_once(__DIR__ . "../../controller/AlunoController.php");

$alunoControl = new AlunoController;

if(!isset($_POST["id"])) {
    
}

$id = $_POST["id"];
$erro = $alunoControl->excluir($id);

if(!$erro) {
    header()
}
