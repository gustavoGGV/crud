<?php
require_once(__DIR__ . "/../../model/Aluno.php");
require_once(__DIR__ . "/../../model/Curso.php");
require_once(__DIR__ . "/../../controller/AlunoController.php");

if(isset($_POST['nome'])) {
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $estrangeiro = $_POST['estrang']; 
    $idCurso = $_POST['curso'];

    $aluno = new Aluno();
    $aluno->setNome($nome);
    $aluno->setIdade($idade);
    $aluno->setEstrangeiro($estrangeiro);

    $curso = new Curso();
    $curso->setId($idCurso);

    $aluno->setCurso($curso);

    $alunoCont = new AlunoController();
    $alunoCont->inserir($aluno);

    header("location: listar.php");
}

include_once(__DIR__ . "/form.php");
?>